/**
 * @file       BlynkSimpleSIM800.h
 * @author     Volodymyr Shymanskyy
 * @license    This project is released under the MIT License (MIT)
 * @copyright  Copyright (c) 2015 Volodymyr Shymanskyy
 * @date       Nov 2016
 * @brief
 *
 */

#ifndef BlynkSimpleSIM800_h
#define BlynkSimpleSIM800_h

#warning "BlynkSimpleSIM800.h is deprecated. Please use BlynkSimpleTinyGSM.h"

#include <BlynkSimpleTinyGSM.h>

#endif
